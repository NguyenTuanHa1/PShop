jQuery(window).on('load', function () {
           jQuery("body").addClass("page-loaded");
            ("loaded")
        });